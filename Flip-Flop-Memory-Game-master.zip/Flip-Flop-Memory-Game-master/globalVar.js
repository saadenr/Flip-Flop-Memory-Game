// store all images in one array
var imgArr=[...Array(13).keys()];
var duplicatedArr=[];
var clickCounter=0;
var choices=[];
var score=0;
